﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SQLite;
using System.Windows;

namespace Racunarski_Sevis
{
    class SqlData
    {

        public SqlData() { }

        public bool KlijentDodaj(Klijent klijent)
        {
            SQLiteConnection con = new SQLiteConnection("Data Source=baza.db3;Version=3;");
            if (con.State == ConnectionState.Closed)
                con.Open();
            try
            {

                String query = "INSERT INTO klijenti(id,ime,prezime,adresa,brojTelefona,email,duzan)values('" + klijent.Id + "','" + klijent.Ime + "','" + klijent.Prezime + "','" + klijent.Adresa + "','" + klijent.BrojTelefona + "','" + klijent.Email + "','" + klijent.Duzan + "')";
                SQLiteCommand cmd = new SQLiteCommand(query, con);
                cmd.ExecuteNonQuery();
                return true;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                con.Close();
            }

        }

        public bool UredjajDodaj(Uredjaj uredjaj)
        {
            SQLiteConnection con = new SQLiteConnection("Data Source=baza.db3;Version=3;");
            if (con.State == ConnectionState.Closed)
                con.Open();
            try
            {

                String query = "INSERT INTO uredjaj(id,idKlijent,naziv,tip,datumPredaje,punjac,torba,mis,usb,ostalo)values('" + uredjaj.Id + "','" + uredjaj.IdKlijent + "','" + uredjaj.Naziv + "','" + uredjaj.Tip + "','" + uredjaj.DatumPredaje + "','" + uredjaj.Punjac + "','" + uredjaj.Torba + "','" + uredjaj.Mis + "','" + uredjaj.Usb + "','" + uredjaj.Ostalo + "')";
                SQLiteCommand cmd = new SQLiteCommand(query, con);
                cmd.ExecuteNonQuery();
                return true;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                con.Close();
            }

        }

        public bool FakturaDodaj(FakturaModel faktura)
        {
            SQLiteConnection con = new SQLiteConnection("Data Source=baza.db3;Version=3;");
            if (con.State == ConnectionState.Closed)
                con.Open();
            try
            {

                String query = "INSERT INTO faktura(id,idKlijent,idUredjaj,opis,datumPopravke,cena,cenaSlovima,datumFakturisanja,placena)values('" + faktura.Id + "','" + faktura.IdKlijent + "','" + faktura.IdUredjaj + "','" + faktura.Opis + "','" + faktura.DatumPopravke + "','" + faktura.Cena + "','" + faktura.CenaSlovima + "','" + faktura.DatumFakturisanja + "','" + faktura.Placena + "')";
                String query1 = "UPDATE klijenti SET duzan = 'True' where id=(" + faktura.IdKlijent + ")";
                SQLiteCommand cmd = new SQLiteCommand(query, con);
                cmd.ExecuteNonQuery();

                SQLiteCommand cmd1 = new SQLiteCommand(query1, con);
                cmd1.ExecuteNonQuery();

                return true;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                con.Close();
            }

        }

        public bool KlijentBirsanje(int id)
        {
            SQLiteConnection con = new SQLiteConnection("Data Source=baza.db3;Version=3;");
            if (con.State == ConnectionState.Closed)
                con.Open();
            try
            {

                String query = "DELETE FROM klijenti WHERE id=(" + id + ")";
                SQLiteCommand cmd = new SQLiteCommand(query, con);
                cmd.ExecuteNonQuery();
                return true;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                con.Close();
            }
        }
        public bool UredjajBirsanje(int id)
        {
            SQLiteConnection con = new SQLiteConnection("Data Source=baza.db3;Version=3;");
            if (con.State == ConnectionState.Closed)
                con.Open();
            try
            {

                String query = "DELETE FROM uredjaj WHERE id=(" + id + ")";
                SQLiteCommand cmd = new SQLiteCommand(query, con);
                cmd.ExecuteNonQuery();
                return true;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                con.Close();
            }
        }
        public bool FakturaBirsanje(int id)
        {
            SQLiteConnection con = new SQLiteConnection("Data Source=baza.db3;Version=3;");
            if (con.State == ConnectionState.Closed)
                con.Open();
            try
            {

                String query = "DELETE FROM faktura WHERE id=(" + id + ")";
                SQLiteCommand cmd = new SQLiteCommand(query, con);
                cmd.ExecuteNonQuery();
                return true;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                con.Close();
            }
        }

        public bool Razduzenje(int id)
        {
            SQLiteConnection con = new SQLiteConnection("Data Source=baza.db3;Version=3;");
            if (con.State == ConnectionState.Closed)
                con.Open();
            try
            {

                String query = "UPDATE faktura SET placena = 'True' where id=(" + id + ")";
                SQLiteCommand cmd = new SQLiteCommand(query, con);
                cmd.ExecuteNonQuery();
                return true;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            finally
            {
                con.Close();
            }
        }



    }
}

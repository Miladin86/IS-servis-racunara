﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Racunarski_Sevis
{
    class Klijent
    {
        private int id;
        private string ime;
        private string prezime;
        private string adresa;
        private string brojTelefona;
        private string email;
        private bool duzan;


        public Klijent()
        {

        }

        public Klijent(int id, string ime, string prezime, string adresa, string brojTelefona, string email)
        {
            Id = id;
            Ime = ime;
            Prezime = prezime;
            Adresa = adresa;
            BrojTelefona = brojTelefona;
            Email = email;
            duzan = false;
        }

        public int Id { get => id; set => id = value; }
        public string Ime { get => ime; set => ime = value; }
        public string Prezime { get => prezime; set => prezime = value; }
        public string Adresa { get => adresa; set => adresa = value; }
        public string BrojTelefona { get => brojTelefona; set => brojTelefona = value; }
        public string Email { get => email; set => email = value; }
        public bool Duzan { get => duzan; set => duzan = value; }

    }
}

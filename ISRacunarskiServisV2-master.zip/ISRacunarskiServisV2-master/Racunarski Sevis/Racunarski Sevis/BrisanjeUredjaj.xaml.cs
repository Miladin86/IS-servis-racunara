﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SQLite;


namespace Racunarski_Sevis
{
    /// <summary>
    /// Interaction logic for BrisanjeUredjaj.xaml
    /// </summary>
    public partial class BrisanjeUredjaj : Window
    {
        public BrisanjeUredjaj()
        {
            InitializeComponent();
        }

        private void PotvrdiDugme_Click(object sender, RoutedEventArgs e)
        {
            if (Validacija())
            {
                SqlData sql = new SqlData();
                if (sql.UredjajBirsanje(int.Parse(idUredjajTextBox.Text)) == false)
                    MessageBox.Show("Polja NISU dodata u bazu", "Obaveštenje", MessageBoxButton.OK, MessageBoxImage.Error);
                else Close();
                ResetFields();
            }
            else
                MessageBox.Show("Polja NISU pravilno popunjena", "Obaveštenje", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void OtkaziDugme_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void ResetFields()
        {
            idUredjajTextBox.Text = "";
            idUredjajTextBox.Background = null;
        }

        private bool Validacija()
        {
            if (string.IsNullOrWhiteSpace(idUredjajTextBox.Text) || System.Text.RegularExpressions.Regex.IsMatch(idUredjajTextBox.Text, "[^0-9]"))
            {
                idUredjajTextBox.Background = Brushes.Red;
                return false;
            }
            else
            {
                idUredjajTextBox.Background = null;
                return true;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Racunarski_Sevis
{
    class FakturaModel
    {
        private int id;
        private int idKlijent;
        private int idUredjaj;
        private string opis;
        private string datumPopravke;
        private double cena;
        private string cenaSlovima;
        private string datumFakturisanja;
        private bool placena;




        public FakturaModel()
        {

        }

        public FakturaModel(int id, int idKlijent, int idUredjaj, string opis, string datumPopravke, double cena, string cenaSlovima, string datumFakturisanja)
        {
            Id = id;
            IdKlijent = idKlijent;
            IdUredjaj = idUredjaj;
            Opis = opis;
            DatumPopravke = datumPopravke;
            Cena = cena;
            CenaSlovima = cenaSlovima;
            DatumFakturisanja = datumFakturisanja;
            placena = false;
        }

        public int Id { get => id; set => id = value; }
        public int IdKlijent { get => idKlijent; set => idKlijent = value; }
        public int IdUredjaj { get => idUredjaj; set => idUredjaj = value; }
        public string Opis { get => opis; set => opis = value; }
        public string DatumPopravke { get => datumPopravke; set => datumPopravke = value; }
        public double Cena { get => cena; set => cena = value; }
        public string CenaSlovima { get => cenaSlovima; set => cenaSlovima = value; }
        public string DatumFakturisanja { get => datumFakturisanja; set => datumFakturisanja = value; }
        public bool Placena { get => placena; set => placena = value; }
    }

}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.Sql;
using System.Data.SQLite;

namespace Racunarski_Sevis
{
    /// <summary>
    /// Interaction logic for KlijentLista.xaml
    /// </summary>
    public partial class KlijentLista : UserControl
    {
        public KlijentLista()
        {
            InitializeComponent();
            UcitajListu();
        }

        private void ObrisiDugme_Click(object sender, RoutedEventArgs e)
        {
            BrisanjeKlijent brisanjeKlijent = new BrisanjeKlijent();
            brisanjeKlijent.Show();
        }

        private void OsveziDugme_Click(object sender, RoutedEventArgs e)
        {
            UcitajListu();
        }

        private void UcitajListu()
        {
            SQLiteConnection con = new SQLiteConnection("Data Source=baza.db3;Version=3;");
            con.Open();
            SQLiteCommand sql_cmd = con.CreateCommand();
            sql_cmd.CommandText = "SELECT * FROM klijenti";
            SQLiteDataAdapter DB = new SQLiteDataAdapter(sql_cmd.CommandText, con);
            DataSet DS = new DataSet();
            DB.Fill(DS);

            if (DS.Tables[0].Rows.Count > 0)
            {
                klijentiDataGrid.ItemsSource = DS.Tables[0].DefaultView;
            }
            con.Close();
        }
    }
    
}

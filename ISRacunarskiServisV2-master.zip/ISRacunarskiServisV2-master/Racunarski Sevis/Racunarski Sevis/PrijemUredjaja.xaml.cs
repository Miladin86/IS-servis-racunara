﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SQLite;

namespace Racunarski_Sevis
{
    /// <summary>
    /// Interaction logic for PrijemUredjaja.xaml
    /// </summary>
    public partial class PrijemUredjaja : UserControl
    {
        public PrijemUredjaja()
        {
            InitializeComponent();
        }

        private void SacuvajDugme_Click(object sender, RoutedEventArgs e)
        {
            if (Validacija())
            {
                Uredjaj uredjaj = new Uredjaj(int.Parse(idPrijemaTextBox.Text), int.Parse(idKlijentaTextBox.Text), uredjajTextBox.Text, tipTextBox.Text, datumPredaje.Text, (bool)punjac.IsChecked, (bool)torba.IsChecked, (bool)mis.IsChecked, (bool)usb.IsChecked, ostaloTextBox.Text);
                SqlData sql = new SqlData();
                if (sql.UredjajDodaj(uredjaj) == false)
                    MessageBox.Show("Polja NISU dodata u bazu", "Obaveštenje", MessageBoxButton.OK, MessageBoxImage.Error);
                ResetFields();
            }
            else
                MessageBox.Show("Polja NISU pravilno popunjena", "Obaveštenje", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void OtkaziDugme_Click(object sender, RoutedEventArgs e)
        {
            ResetFields();
        }

        private void ResetFields()
        {
            idKlijentaTextBox.Text = "";
            idPrijemaTextBox.Text = "";
            uredjajTextBox.Text = "";
            tipTextBox.Text = "";
            ostaloTextBox.Text = "";
            punjac.IsChecked = false;
            torba.IsChecked = false;
            mis.IsChecked = false;
            usb.IsChecked = false;
            datumPredaje.SelectedDate = null;

            idKlijentaTextBox.Background = null;
            idPrijemaTextBox.Background = null;
            uredjajTextBox.Background = null;
            tipTextBox.Background = null;
            datumPredaje.Background = null;


        }

        private bool Validacija()
        {

            bool ver1 = false;
            bool ver2 = false;
            bool ver3 = false;
            bool ver4 = false;
            bool ver5 = false;


            if (string.IsNullOrEmpty(idKlijentaTextBox.Text) || System.Text.RegularExpressions.Regex.IsMatch(idKlijentaTextBox.Text, "[^0-9]"))
            {
                idKlijentaTextBox.Background = Brushes.Red;
                ver1 = false;
            }
            else
            {
                idKlijentaTextBox.Background = null;
                ver1 = true;
            }
            if (string.IsNullOrEmpty(idPrijemaTextBox.Text) || System.Text.RegularExpressions.Regex.IsMatch(idPrijemaTextBox.Text, "[^0-9]"))
            {
                idPrijemaTextBox.Background = Brushes.Red;
                ver2 = false;
            }
            else
            {
                idPrijemaTextBox.Background = null;
                ver2 = true;
            }
            if (string.IsNullOrEmpty(uredjajTextBox.Text))
            {
                uredjajTextBox.Background = Brushes.Red;
                ver3 = false;
            }
            else
            {
                uredjajTextBox.Background = null;
                ver3 = true;
            }
            if (string.IsNullOrEmpty(tipTextBox.Text) || System.Text.RegularExpressions.Regex.IsMatch(tipTextBox.Text, "[^A-ž]"))
            {
                tipTextBox.Background = Brushes.Red;
                ver4 = false;
            }
            else
            {
                tipTextBox.Background = null;
                ver4 = true;
            }
            if (string.IsNullOrEmpty(datumPredaje.Text))
            {
                datumPredaje.Background = Brushes.Red;
                ver5 = false;
            }
            else
            {
                datumPredaje.Background = null;
                ver5 = true;
            }


            if (ver1 && ver2 && ver3 && ver4 && ver5)
                return true;
            else return false;
        }
    }
}

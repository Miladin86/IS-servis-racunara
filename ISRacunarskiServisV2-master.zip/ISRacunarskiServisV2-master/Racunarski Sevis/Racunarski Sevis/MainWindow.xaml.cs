﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Racunarski_Sevis
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Dugme_Izlaz_Click(object sender, MouseButtonEventArgs e)
        {
            System.Windows.Application.Current.Shutdown();
        }

        private void Dugme_Izrada_Click(object sender, MouseButtonEventArgs e)
        {
            

            logo.Visibility = Visibility.Collapsed;
            dodavanjeKlijenta.Visibility = Visibility.Collapsed;
            listaKlijenta.Visibility = Visibility.Collapsed;
            razduzenjeKlijent.Visibility = Visibility.Collapsed;
            prijemUredjaja.Visibility = Visibility.Collapsed;
            listaUredjaj.Visibility = Visibility.Collapsed;
            faktura.Visibility = Visibility.Collapsed;
            listaFaktura.Visibility = Visibility.Collapsed;

            izrada.Visibility = Visibility.Visible;

        }

        private void Dugme_Logo_Click(object sender, MouseButtonEventArgs e)
        {
            

            izrada.Visibility = Visibility.Collapsed;
            dodavanjeKlijenta.Visibility = Visibility.Hidden;
            listaKlijenta.Visibility = Visibility.Collapsed;
            razduzenjeKlijent.Visibility = Visibility.Collapsed;
            prijemUredjaja.Visibility = Visibility.Collapsed;
            listaUredjaj.Visibility = Visibility.Collapsed;
            faktura.Visibility = Visibility.Collapsed;
            listaFaktura.Visibility = Visibility.Collapsed;

            logo.Visibility = Visibility.Visible;

        }

        private void Dugme_Dodavanje_Click(object sender, MouseButtonEventArgs e)
        {
            

            logo.Visibility = Visibility.Collapsed;
            izrada.Visibility = Visibility.Collapsed;
            listaKlijenta.Visibility = Visibility.Collapsed;
            razduzenjeKlijent.Visibility = Visibility.Collapsed;
            prijemUredjaja.Visibility = Visibility.Collapsed;
            listaUredjaj.Visibility = Visibility.Collapsed;
            faktura.Visibility = Visibility.Collapsed;
            listaFaktura.Visibility = Visibility.Collapsed;

            dodavanjeKlijenta.Visibility = Visibility.Visible;
        }

        private void Dugme_ListaKlijenta_Click(object sender, MouseButtonEventArgs e)
        {
            

            logo.Visibility = Visibility.Collapsed;
            izrada.Visibility = Visibility.Collapsed;
            dodavanjeKlijenta.Visibility = Visibility.Collapsed;
            razduzenjeKlijent.Visibility = Visibility.Collapsed;
            prijemUredjaja.Visibility = Visibility.Collapsed;
            listaUredjaj.Visibility = Visibility.Collapsed;
            faktura.Visibility = Visibility.Collapsed;
            listaFaktura.Visibility = Visibility.Collapsed;

            listaKlijenta.Visibility = Visibility.Visible;
        }

        private void Dugme_Rezduzenje_Click(object sender, MouseButtonEventArgs e)
        {
            

            logo.Visibility = Visibility.Collapsed;
            izrada.Visibility = Visibility.Collapsed;
            dodavanjeKlijenta.Visibility = Visibility.Collapsed;
            listaKlijenta.Visibility = Visibility.Collapsed;
            prijemUredjaja.Visibility = Visibility.Collapsed;
            listaUredjaj.Visibility = Visibility.Collapsed;
            faktura.Visibility = Visibility.Collapsed;
            listaFaktura.Visibility = Visibility.Collapsed;

            razduzenjeKlijent.Visibility = Visibility.Visible;
        }

        private void Dugme_Prijem_Click(object sender, MouseButtonEventArgs e)
        {
            

            logo.Visibility = Visibility.Collapsed;
            izrada.Visibility = Visibility.Collapsed;
            dodavanjeKlijenta.Visibility = Visibility.Collapsed;
            listaKlijenta.Visibility = Visibility.Collapsed;
            razduzenjeKlijent.Visibility = Visibility.Collapsed;
            listaUredjaj.Visibility = Visibility.Collapsed;
            faktura.Visibility = Visibility.Collapsed;
            listaFaktura.Visibility = Visibility.Collapsed;

            prijemUredjaja.Visibility = Visibility.Visible;
        }

        private void Dugme_Lista_Click(object sender, MouseButtonEventArgs e)
        {
            

            logo.Visibility = Visibility.Collapsed;
            izrada.Visibility = Visibility.Collapsed;
            dodavanjeKlijenta.Visibility = Visibility.Collapsed;
            listaKlijenta.Visibility = Visibility.Collapsed;
            razduzenjeKlijent.Visibility = Visibility.Collapsed;
            prijemUredjaja.Visibility = Visibility.Collapsed;
            faktura.Visibility = Visibility.Collapsed;
            listaFaktura.Visibility = Visibility.Collapsed;

            listaUredjaj.Visibility = Visibility.Visible;
        }

        private void Dugme_Faktura_Click(object sender, MouseButtonEventArgs e)
        {
            

            logo.Visibility = Visibility.Collapsed;
            izrada.Visibility = Visibility.Collapsed;
            dodavanjeKlijenta.Visibility = Visibility.Collapsed;
            listaKlijenta.Visibility = Visibility.Collapsed;
            razduzenjeKlijent.Visibility = Visibility.Collapsed;
            prijemUredjaja.Visibility = Visibility.Collapsed;
            listaUredjaj.Visibility = Visibility.Collapsed;
            listaFaktura.Visibility = Visibility.Collapsed;

            faktura.Visibility = Visibility.Visible;
        }

        private void Dugme_ListaFaktura_Click(object sender, MouseButtonEventArgs e)
        {
            

            logo.Visibility = Visibility.Collapsed;
            izrada.Visibility = Visibility.Collapsed;
            dodavanjeKlijenta.Visibility = Visibility.Collapsed;
            listaKlijenta.Visibility = Visibility.Collapsed;
            razduzenjeKlijent.Visibility = Visibility.Collapsed;
            prijemUredjaja.Visibility = Visibility.Collapsed;
            listaUredjaj.Visibility = Visibility.Collapsed;
            faktura.Visibility = Visibility.Collapsed;

            listaFaktura.Visibility = Visibility.Visible;
        }

        private void Dugme_Pomoc_Click(object sender, MouseButtonEventArgs e)
        {
            System.Diagnostics.Process.Start(Directory.GetCurrentDirectory() + @"\res\pomoc.chm");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Racunarski_Sevis
{
    /// <summary>
    /// Interaction logic for Faktura.xaml
    /// </summary>
    public partial class Faktura : UserControl
    {
        public Faktura()
        {
            InitializeComponent();
        }

        private void SacuvajDugme_Click(object sender, RoutedEventArgs e)
        {
            if (Validacija())
            {
                FakturaModel faktura = new FakturaModel(int.Parse(brojFakture.Text), int.Parse(idKlijenatTextBox.Text), int.Parse(idUredjajTextBox.Text), opisTextBox.Text, datumPopravke.Text, double.Parse(cenaTextBox.Text), cenaSlovimaTextBox.Text, datumFakture.Text);
                SqlData sql = new SqlData();
                if (sql.FakturaDodaj(faktura) == false)
                    MessageBox.Show("Polja NISU dodata u bazu", "Obaveštenje", MessageBoxButton.OK, MessageBoxImage.Error);
                ResetFields();
            }
            else
                MessageBox.Show("Polja NISU pravilno popunjena", "Obaveštenje", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void OtkaziDugme_Click(object sender, RoutedEventArgs e)
        {
            ResetFields();
        }

        private void ResetFields()
        {
            brojFakture.Text = "";
            idKlijenatTextBox.Text = "";
            idUredjajTextBox.Text = "";
            opisTextBox.Text = "";
            datumFakture.SelectedDate = null;
            datumPopravke.SelectedDate = null;
            cenaSlovimaTextBox.Text = "";
            cenaTextBox.Text = "";

            brojFakture.Background = null;
            idKlijenatTextBox.Background = null;
            idUredjajTextBox.Background = null;
            opisTextBox.Background = null;
            datumFakture.Background = null;
            datumPopravke.Background = null;
            cenaSlovimaTextBox.Background = null;
            cenaTextBox.Background = null;
        }

        private bool Validacija()
        {

            bool ver1 = false;
            bool ver2 = false;
            bool ver3 = false;
            bool ver4 = false;
            bool ver5 = false;
            bool ver6 = false;
            bool ver7 = false;
            bool ver8 = false;

            if (string.IsNullOrEmpty(brojFakture.Text) || System.Text.RegularExpressions.Regex.IsMatch(brojFakture.Text, "[^0-9]"))
            {
                brojFakture.Background = Brushes.Red;
                ver1 = false;
            }
            else
            {
                brojFakture.Background = null;
                ver1 = true;
            }
            if (string.IsNullOrEmpty(idKlijenatTextBox.Text) || System.Text.RegularExpressions.Regex.IsMatch(idKlijenatTextBox.Text, "[^0-9]"))
            {
                idKlijenatTextBox.Background = Brushes.Red;
                ver2 = false;
            }
            else
            {
                idKlijenatTextBox.Background = null;
                ver2 = true;
            }
            if (string.IsNullOrEmpty(idUredjajTextBox.Text) || System.Text.RegularExpressions.Regex.IsMatch(idUredjajTextBox.Text, "[^0-9]"))
            {
                idUredjajTextBox.Background = Brushes.Red;
                ver3 = false;
            }
            else
            {
                idUredjajTextBox.Background = null;
                ver3 = true;
            }
            if (string.IsNullOrEmpty(opisTextBox.Text))
            {
                opisTextBox.Background = Brushes.Red;
                ver4 = false;
            }
            else
            {
                opisTextBox.Background = null;
                ver4 = true;
            }
            if (string.IsNullOrEmpty(datumFakture.Text))
            {
                datumFakture.Background = Brushes.Red;
                ver5 = false;
            }
            else
            {
                datumFakture.Background = null;
                ver5 = true;
            }
            if (string.IsNullOrEmpty(datumPopravke.Text))
            {
                datumPopravke.Background = Brushes.Red;
                ver6 = false;
            }
            else
            {
                datumPopravke.Background = null;
                ver6 = true;
            }
            if (string.IsNullOrEmpty(cenaSlovimaTextBox.Text) || System.Text.RegularExpressions.Regex.IsMatch(cenaSlovimaTextBox.Text, "[^A-ž]"))
            {
                cenaSlovimaTextBox.Background = Brushes.Red;
                ver7 = false;
            }
            else
            {
                cenaSlovimaTextBox.Background = null;
                ver7 = true;
            }
            if (string.IsNullOrEmpty(cenaTextBox.Text))
            {
                cenaTextBox.Background = Brushes.Red;
                ver8 = false;
            }
            else
            {
                cenaTextBox.Background = null;
                ver8 = true;
            }

            if (ver1 && ver2 && ver3 && ver4 && ver5 && ver6 && ver7 && ver8)
                return true;
            else return false;
        }
    }
}

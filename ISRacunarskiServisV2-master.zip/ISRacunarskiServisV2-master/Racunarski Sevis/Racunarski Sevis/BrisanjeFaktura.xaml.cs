﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SQLite;

namespace Racunarski_Sevis
{
    /// <summary>
    /// Interaction logic for BrisanjeFaktura.xaml
    /// </summary>
    public partial class BrisanjeFaktura : Window
    {
        public BrisanjeFaktura()
        {
            InitializeComponent();
        }

        private void PotvrdiDugme_Click(object sender, RoutedEventArgs e)
        {
            if (Validacija())
            {
                SqlData sql = new SqlData();
                if (sql.FakturaBirsanje(int.Parse(idFaktureTextBox.Text)) == false) 
                    MessageBox.Show("Polja NISU dodata u bazu", "Obaveštenje", MessageBoxButton.OK, MessageBoxImage.Error);
                else Close();
                ResetFields();
                
            }
            else
                MessageBox.Show("Polja NISU pravilno popunjena", "Obaveštenje", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void OtkaziDugme_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void ResetFields()
        {
            idFaktureTextBox.Text = "";
            idFaktureTextBox.Background = null;
        }

        private bool Validacija()
        {
            if (string.IsNullOrWhiteSpace(idFaktureTextBox.Text) || System.Text.RegularExpressions.Regex.IsMatch(idFaktureTextBox.Text, "[^0-9]"))
            {
                idFaktureTextBox.Background = Brushes.Red;
                return false;
            }
            else
            {
                idFaktureTextBox.Background = null;
                return true;
            }
        }
    }
}

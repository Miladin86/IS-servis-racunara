﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Racunarski_Sevis
{
    class Uredjaj
    {
        private int id;
        private int idKlijent;
        private string naziv;
        private string tip;
        private string datumPredaje;
        private bool punjac;
        private bool torba;
        private bool mis;
        private bool usb;
        private string ostalo;

        public Uredjaj()
        {

        }

        public Uredjaj(int id, int idKlijent, string naziv, string tip, string datumPredaje, bool punjac, bool torba, bool mis, bool usb, string ostalo)
        {
            Id = id;
            IdKlijent = idKlijent;
            Naziv = naziv;
            Tip = tip;
            DatumPredaje = datumPredaje;
            Punjac = punjac;
            Torba = torba;
            Mis = mis;
            Usb = usb;
            Ostalo = ostalo;
        }

        public int Id { get => id; set => id = value; }
        public int IdKlijent { get => idKlijent; set => idKlijent = value; }
        public string Naziv { get => naziv; set => naziv = value; }
        public string Tip { get => tip; set => tip = value; }
        public string DatumPredaje { get => datumPredaje; set => datumPredaje = value; }
        public bool Punjac { get => punjac; set => punjac = value; }
        public bool Torba { get => torba; set => torba = value; }
        public bool Mis { get => mis; set => mis = value; }
        public bool Usb { get => usb; set => usb = value; }
        public string Ostalo { get => ostalo; set => ostalo = value; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SQLite;

namespace Racunarski_Sevis
{
    /// <summary>
    /// Interaction logic for KlijentDodavanje.xaml
    /// </summary>
    public partial class KlijentDodavanje : UserControl
    {
        public KlijentDodavanje()
        {
            InitializeComponent();
        }

        private void OtkaziDugme_Click(object sender, RoutedEventArgs e)
        {
            ResetFields();
        }

        private void SacuvajDugme_Click(object sender, RoutedEventArgs e)
        {

            if (Validacija())
            {
                Klijent klijent = new Klijent(int.Parse(idKlijenatTextBox.Text), imeTextBox.Text, prezimeTextBox.Text, adresaTextBox.Text, brojTelefonaTextBox.Text, emailTextBox.Text);
                SqlData sql = new SqlData();
                if (sql.KlijentDodaj(klijent) == false)
                    MessageBox.Show("Polja NISU dodata u bazu", "Obaveštenje", MessageBoxButton.OK, MessageBoxImage.Error);
                ResetFields();
            }
            else
                MessageBox.Show("Polja NISU pravilno popunjena", "Obaveštenje", MessageBoxButton.OK, MessageBoxImage.Error);

        }

        private void ResetFields()
        {
            idKlijenatTextBox.Text = "";
            imeTextBox.Text = "";
            prezimeTextBox.Text = "";
            adresaTextBox.Text = "";
            brojTelefonaTextBox.Text = "";
            emailTextBox.Text = "";

            idKlijenatTextBox.Background = null;
            imeTextBox.Background = null;
            prezimeTextBox.Background = null;
            adresaTextBox.Background = null;
            brojTelefonaTextBox.Background = null;
            emailTextBox.Background = null;
        }

        private bool Validacija()
        {

            bool ver1 = false;
            bool ver2 = false;
            bool ver3 = false;
            bool ver4 = false;
            bool ver5 = false;
            bool ver6 = false;

            if (string.IsNullOrEmpty(idKlijenatTextBox.Text) || System.Text.RegularExpressions.Regex.IsMatch(idKlijenatTextBox.Text, "[^0-9]"))
            {
                idKlijenatTextBox.Background = Brushes.Red;
                ver1 = false;
            }
            else
            {
                idKlijenatTextBox.Background = null;
                ver1 = true;
            }
            if (string.IsNullOrEmpty(imeTextBox.Text) || System.Text.RegularExpressions.Regex.IsMatch(imeTextBox.Text, "[^A-ž]"))
            {
                imeTextBox.Background = Brushes.Red;
                ver2 = false;
            }
            else
            {
                imeTextBox.Background = null;
                ver2 = true;
            }
            if (string.IsNullOrEmpty(prezimeTextBox.Text) || System.Text.RegularExpressions.Regex.IsMatch(prezimeTextBox.Text, "[^A-ž]"))
            {
                prezimeTextBox.Background = Brushes.Red;
                ver3 = false;
            }
            else
            {
                prezimeTextBox.Background = null;
                ver3 = true;
            }
            if (string.IsNullOrEmpty(adresaTextBox.Text))
            {
                adresaTextBox.Background = Brushes.Red;
                ver4 = false;
            }
            else
            {
                adresaTextBox.Background = null;
                ver4 = true;
            }
            if (string.IsNullOrEmpty(brojTelefonaTextBox.Text) || System.Text.RegularExpressions.Regex.IsMatch(brojTelefonaTextBox.Text, "[^0-9]"))
            {
                brojTelefonaTextBox.Background = Brushes.Red;
                ver5 = false;
            }
            else
            {
                brojTelefonaTextBox.Background = null;
                ver5 = true;
            }
            if (string.IsNullOrEmpty(emailTextBox.Text))
            {
                emailTextBox.Background = Brushes.Red;
                ver6 = false;
            }
            else
            {
                emailTextBox.Background = null;
                ver6 = true;
            }

            if (ver1 && ver2 && ver3 && ver4 && ver5 && ver6)
                return true;
            else return false;
        }
    }
}

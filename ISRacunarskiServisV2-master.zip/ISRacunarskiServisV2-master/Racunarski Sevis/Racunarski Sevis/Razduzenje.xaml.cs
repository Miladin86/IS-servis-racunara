﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SQLite;

namespace Racunarski_Sevis
{
    /// <summary>
    /// Interaction logic for Razduzenje.xaml
    /// </summary>
    public partial class Razduzenje : UserControl
    {
        public Razduzenje()
        {
            InitializeComponent();
        }
        private void OtkaziDugme_Click(object sender, RoutedEventArgs e)
        {
            ResetFields();
        }

        private void PotvrdiDugme_Click(object sender, RoutedEventArgs e)
        {


            if (Validacija())
            {
                SqlData sql = new SqlData();
                if (sql.Razduzenje(int.Parse(idFakturaTextBox.Text)) == false)
                    MessageBox.Show("Polja NISU dodata u bazu", "Obaveštenje", MessageBoxButton.OK, MessageBoxImage.Error);
                ResetFields();
            }
            else
                MessageBox.Show("Polja NISU pravilno popunjena", "Obaveštenje", MessageBoxButton.OK, MessageBoxImage.Error);

        }

        private void ResetFields()
        {
            idFakturaTextBox.Text = "";
            idFakturaTextBox.Background = null;
        }

        private bool Validacija()
        {
            if (string.IsNullOrWhiteSpace(idFakturaTextBox.Text) || System.Text.RegularExpressions.Regex.IsMatch(idFakturaTextBox.Text, "[^0-9]"))
            {
                idFakturaTextBox.Background = Brushes.Red;
                return false;
            }
            else return true;
        }
    }
}
